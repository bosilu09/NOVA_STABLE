module.exports = {
  name: "file",
  alias: ["fl","flie"],
  desc: "Say hello to bot.",
  react: "⚙️",
  category: "Core",
  start: async (Miku, m, { pushName, prefix,args }) => {
   
    
  },
};
