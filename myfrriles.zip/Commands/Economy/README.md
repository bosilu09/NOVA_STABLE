<h1 align="center">🎀 Economy Usage Rules 🎀
</h1>

<br>

- You are not allowed to manipulate the economy system.
- You are not allowed to use the economy system for your own benefit/show off.
- You are not allowed to change the public database added for Economy.

<br>

### Note:
#### Economy is a game and you should play fare and without cheating.
#### If you break these rules you will not get any support from us.