
module.exports = {
    name: "yt",
    alias: ["repo","sc","sourcecode"],
    desc: "Say hello to bot.",
    react: "",
    category: "Misc",
    start: async (Miku, m, { text,pushName, prefix ,args}) => {
       m.reply(`*_.yt_ is a Removed Feature Use *.video* Insetead*`)
}
}
