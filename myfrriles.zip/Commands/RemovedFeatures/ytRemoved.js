
module.exports = {
    name: "yts",
    alias: ["repo","sc","sourcecode"],
    desc: "Say hello to bot.",
    react: "",
    category: "Misc",
    start: async (Miku, m, { text,pushName, prefix ,args}) => {
       m.reply(`*_.yts_ is a Removed Feature Use *.video* Insetead*`)
}
}
